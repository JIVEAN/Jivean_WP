<html>
<head>
	<meta charset="utf-8">
	<title>Student Marks</title>
	<style>
		table {
			border-style: outset;
			border-width: 7px;
			border-color: blueviolet;
		}
	</style>
</head>
<body>
	<?php				
		$FName = $_POST["FName"];   
		$matricNo = $_POST["matricNo"];    
		$gender = $_POST["gender"];     
		$address = $_POST["address"]; 
		$class = $_POST["class"];          
		$email = $_POST["email"];	        
		$csmark = $_POST["csmark"] * 0.15;	
		$pbtmark = $_POST["pbtmark"] * 0.25;	
		$labmark = $_POST["labmark"] * 0.2;
		$presentmark = $_POST["presentmark"] * 0.1;
		$practmark = $_POST["practmark"] * 0.3;
	
		$total = $csmark + $pbtmark + $labmark + $presentmark + $practmark;
	?> 	
	
	<h2 align="center">:: RECORDED MARKS :: </h2> 
  	<table align="center" width="40%">
		<tr>
<td colspan="3"><?php echo "<i><b><font size='4' color='Blue'>Hello, ". strtoupper($FName)."</font></b></i>"; ?></td>
	              </tr>
		<tr>
		  <th colspan="3">&nbsp;</th>
		</tr>
		<tr>
		  <td>Matric Number</td>
		  <td>:</td>				
		  <td><?php echo strtoupper($matricNo); ?></td> 
		</tr>
		<tr>
		  <td>Gender</td>
		  <td>:</td>				
		  <td><?php echo strtoupper($gender); ?></td> 
		</tr>
		<tr>
		  <td>Address</td>
		  <td>:</td>							  <td><?php echo strtoupper($address); ?></td>
		</tr>
		<tr>
		  <td>Class</td>
		  <td>:</td>	
		  <td><?php echo $class; ?></td>
		</tr>
		<tr>
		  <td>Email</td>
		  <td>:</td>
		  <td><?php echo $email; ?></td>
		<tr>
      	              <td colspan="3">&nbsp;</td>
		</tr>
		<tr>
<th colspan="3">Marks for DFP50193 Web Programming</th>
		</tr>
		<tr>
		  <th colspan="3">&nbsp;</th>
		</tr>
		<tr>
		  <td>Case Study Marks</td>
		  <td>:</td>
		  <td><?php echo $csmark; ?> /15%</td>
		<td></td>
		</tr>
		<tr>
		  <td>Problem Base Task Marks</td>
		  <td>:</td>
		  <td><?php echo $pbtmark; ?> /25%</td>
		</tr>
		<tr>
		  <td>Lab Task Marks</td>
		  <td>:</td>
		  <td><?php echo $labmark; ?> /20%</td>
		</tr>
		<tr>
		  <td>Presentations Marks</td>
		  <td>:</td>
		  <td><?php echo $presentmark; ?> /10%</td>
		</tr>
		<tr>
		  <td>Practical Test Marks</td>
		  <td>:</td>
		  <td><?php echo $practmark; ?> /30%</td>
		</tr>
		<tr>
		  <td><b>Total Marks</b></td>
		  <td>:</td>
		  <td><b><?php echo $total; ?> /100%</b></td>
	                </tr>
                                <tr>
			<td><b>Your Result</b></td>
			<td>:</td>
			<td>
			<?php
if ($total <40) 				
echo "<i><b><font size='4' color='Red'>You are failed! Please repeat this course again...</font></b></i>";
elseif ($total >=40 and $total <=46)	
echo "<i><b><font size='4' color='Red'>Your grade is D</font></b></i>";
elseif ($total >=47 and $total <=59)	
echo "<i><b><font size='4' color='Red'> Your grade is C</font></b></i>";
elseif ($total >=60 and $total <=74)		echo "<i><b><font size='4' color='Red'>Your grade is B</font></b></i>";
elseif ($total >=75 and $total <=79)		echo "<i><b><font size='4' color='Red'>Your grade is A-</font></b></i>";
elseif ($total >=80 and $total <=89)		echo "<i><b><font size='4' color='Red'>Your grade is A</font></b></i>";
elseif ($total >=90 and $total <=100)		echo "<i><b><font size='4' color='Red'>Your grade is A+</font></b></i>";
else					
	echo "<i><b><font size='4' color='Red'>Input error! Your marks entered is invalid!</font></b></i>";
			?>
		    </td>
		    </tr>
</table>
</body>
</html>
