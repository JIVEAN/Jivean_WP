<!doctype html>
<html>
<head>
<title>Recorded Information</title>
<style type="text/css">
    .style7 {
        font-family: Geneva, Arial, Helvetica, sans-serif; 
        font-weight: bold;
    }
    body {
        background-color: #ffffff;
    }
    table {
        border: 2px solid black;
        border-collapse: collapse;
        width: 50%;
        margin: auto;
    }
    th, td {
        text-align: left;
        padding: 1px;
    }
    tr:nth-child(even) {
        background-color: #ffffff;
    }
    .error {
        color: #FF0000;
    }
</style>
</head>
<body>

<?php
function sanitize_input($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

$name = isset($_POST["name"]) ? sanitize_input($_POST["name"]) : ""; 
$phone = isset($_POST["phone"]) ? sanitize_input($_POST["phone"]) : ""; 
$email = isset($_POST["email"]) ? sanitize_input($_POST["email"]) : ""; 
$address = isset($_POST["address"]) ? sanitize_input($_POST["address"]) : ""; 
$qpepper = isset($_POST["qpepper"]) ? (int)sanitize_input($_POST["qpepper"]) : 0; 
$qsuper = isset($_POST["qsuper"]) ? (int)sanitize_input($_POST["qsuper"]) : 0; 

$pepper = isset($_POST['pepper']) ? sanitize_input($_POST['pepper']) : 'Pizza Not Selected';
$super = isset($_POST['super']) ? sanitize_input($_POST['super']) : 'Pizza Not Selected';
$methods = isset($_POST['methods']) ? sanitize_input($_POST['methods']) : '*methods Not Selected';
$discount = isset($_POST['discount']) ? sanitize_input($_POST['discount']) : 'Pizza Not Selected';

$name2 = strtoupper($name);
?> 

<h2 align="center" class="style7">:: RECORDED INFORMATION ::</h2>
<table>
    <tr>
        <td height="30" colspan="3">
            <?php echo "<i><b><font style='font-family:arial;' size='4' color='Blue'>Hello, " . $name2 . "</font></b></i>"; ?>
        </td>
    </tr>
    <tr>
        <td height="30"><span class="style7">Phone Number</span></td>
        <td><span class="style7">:</span></td>
        <td><span class="style7"><?php echo $phone; ?></span></td>
    </tr>
    <tr>
        <td height="30"><span class="style7">Email</span></td>
        <td><span class="style7">:</span></td>
        <td><span class="style7"><?php echo $email; ?></span></td>
    </tr>
    <tr>
        <td height="48"><span class="style7">Address</span></td>
        <td><span class="style7">:</span></td>
        <td><span class="style7"><?php echo strtoupper($address); ?></span></td>
    </tr>
    <tr>
        <td><span class="style7">Your preferred method is</span></td>
        <td><span class="style7">:</span></td>
        <td><span class="style7"><?php echo strtoupper($methods); ?></span></td>
    </tr>
    <tr><td><br></td></tr>
    <tr>
        <td colspan="3"><span class="style7"><font style='font-family:arial;' size='4' color='Blue'>Here is Your Order</font></span></td>
    </tr>
    <?php
    $total = 0;
    if ($methods == 'Delivery') {
        $delivery_charge = 10;
    } else {
        $delivery_charge = 0;
    }

    if ($qpepper > 0) {
        echo "<tr>
                <td><span class='style7'>Your Order is</span></td>
                <td><span class='style7'>:</span></td>
                <td><span class='style7'>{$qpepper} PIZZA " . strtoupper($pepper) . "</span></td>
              </tr>";
        $total += $qpepper * 15;
    }

    if ($qsuper > 0) {
        echo "<tr>
                <td><span class='style7'>Your Order is</span></td>
                <td><span class='style7'>:</span></td>
                <td><span class='style7'>{$qsuper} PIZZA " . strtoupper($super) . "</span></td>
              </tr>";
        $total += $qsuper * 14;
    }

    if ($total > 0) {
        $total += $delivery_charge;
        if ($methods == 'CarryOut') {
            $total *= 0.98; // 2% discount
        }
        echo "<tr>
                <td><span class='style7'>Your Total Order is</span></td>
                <td><span class='style7'>:</span></td>
                <td><span class='style7'>RM " . number_format($total, 2) . "</span></td>
              </tr>";
    } else {
        echo "<tr>
                <td colspan='3'><span class='style7'>You did not select any menu items</span></td>
              </tr>";
    }
    ?>
</table>
</body>
</html>
