<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Member Information</title>
	<style>
		table {
			border-style: outset;
			border-width: 7px;
			border-color: blueviolet;
		}
	</style>
</head>

<body>
	
	<?php				
		$FName = $_POST["FName"];   
		$icNo = $_POST["icNo"];    
		$gender = $_POST["gender"];     
		$address = $_POST["address"]; 
		$phoneNo = $_POST["phoneNo"];
		$session = $_POST["session"];          
		$email = $_POST["email"];	        
		$height = $_POST["height"];	
		$weight = $_POST["weight"];	
	?> 	
	
	<h2 align="center">:: RECORDED INFORMATION :: </h2> 
  	<table align="center" width="40%">
    <tr>
		  <td colspan="3"><?php echo "<i><b><font size='4' color='Blue'>Hello, ". strtoupper($FName)."</font></b></i>"; ?></td>
      </tr>
	<tr>
		<td colspan="3">&nbsp;</td>
	</tr>
    <tr>
      <td>IC Number</td>
      <td>:</td>
      <td><?php echo $icNo; ?></td>				 
    </tr>
    <tr>
      <td>Gender</td>
      <td>:</td>
		<td><?php echo strtoupper($gender); ?></td>
    </tr>
    <tr>
      <td>Address</td>
      <td>:</td>
      <td><?php echo strtoupper($address); ?></td>
    </tr>
    <tr>
      <td>Phone Number</td>
      <td>:</td>
      <td><?php echo $phoneNo; ?></td>
    </tr>
    <tr>
      <td>Gym Session</td>
      <td>:</td>
      <td><?php echo strtoupper($session); ?></td>
    </tr>
    <tr>
      <td>Email</td>	
      <td>:</td>
      <td><?php echo $email; ?></td>
    </tr>
    <tr>
      <td>Height </td>
      <td>:</td>							
      <td><?php echo $height; ?> meter</td>
    </tr>
	<tr>
	  <td>Weight  </td>
      <td>:</td>							
      <td><?php echo $weight; ?> kilogram</td>
    </tr>
	<tr>
		<td colspan="3">&nbsp;</td>
	</tr>
	<tr>
		<th colspan="3" align="left"><?php echo "<i><b><font size='4' color='Blue'>Result for ". strtoupper($FName)."</font></b></i>"; ?></th>
	</tr>
	<tr>
		<td><b>Your BMI is </b>
		<td>:</td>
		<td><b>
            <?php 
					$bmi = ($weight/($height * $height)); 
					echo round($bmi) ." kg/m2"?>
		</b></td>
	<tr>
		<td colspan><b>Your are in category </b></td>
			<td>:</td>
			<td>
			<?php 
   	
			if ($bmi <15) 				
				echo "<font color='Red'>"."<i>"."<b> Severely underweight!</b>"."</font>"."</i>";
			elseif ($bmi >=15 and $bmi <18.5)	
				echo "<font color='Red'>"."<i>"."<b>Underweight!</b>"."</font>"."</i>";
			elseif ($bmi >=18.5 and $bmi <25)	
				echo "<font color='Blue'>"."<i>"." <b>Congratulations! Normal, healthy weight...</b>"."</font>"."</i>";
			elseif ($bmi >=25 and $bmi <30)		
				echo "<font color='Red'>"."<i>"." <b>Overweight!</b>"."</font>"."</i>";
			elseif ($bmi >=30 and $bmi <35)		
				echo "<font color='Red'>"."<i>"." <b>Obese Class I, moderately obese! </b>"."</font>"."</i>";
			elseif ($bmi >=35 and $bmi <40)		
				echo "<font color='Red'>"."<i>"." <b>Obese Class II, severely obese!</b>"."</font>"."</i>";
			elseif ($bmi >40)			
				echo "<font color='Red'>"."<i>"." <b>Obese Class III, very severely obese!</b>"."</font>"."</i>";
			else					
				echo "<i>"."<font color='Red'>"."<b>Input error! Your height and weight entered is invalid!</b>"."</font>"."</i>";
	    	?>
		</td>
	</tr>
	</table>
</body>
</html>
