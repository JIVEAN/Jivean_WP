<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Travel Reservation Information</title>
	<style>
		table {
			border-style: outset;
			border-width: 7px;
			border-color: firebrick;
		}
	</style>
</head>


<body style="font-family:Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, 'sans-serif'">
	<?php				
		$fullname = $_POST["fullname"];   
		$phone = $_POST["phone"];        
		$email = $_POST["email"]; 
		$destination = $_POST["destination"];  
		$depart= $_POST["depart"];
		$time= $_POST["time"];
		$person= $_POST["person"];	        
		$avail = $_POST["avail"];	
		$discount = $_POST["discount"];	
	?> 	

<h1 align="center">Travel Reservation Information</h1>
<h2 align="center"><?php echo "<i><b><font color='Blue'>Hi, ". strtoupper($fullname)."</font></b></i>"; ?> </h2>
		<table width="40%" align="center">
	      <tr>
	        <td colspan="3">Your recorded information as follow:</td>
          </tr>
		 <tr>
	        <td colspan="3">&nbsp;</td>
          </tr>
	      <tr>
	        <td>Phone number </td>
	        <td>:</td>
	        <td><?php echo $phone ?></td>
          </tr>
	      <tr>
	        <td>Email address </td>
	        <td>:</td>
	        <td><?php echo $email?></td>
          </tr>
	      <tr>
	        <td>Destination </td>
	        <td>:</td>
	        <td><?php echo $destination ?></td>
          </tr>
	      <tr>
	        <td>Departure date </td>
	        <td>:</td>
	        <td><?php echo $depart?></td>
          </tr>
	      <tr>
	        <td>Departure time</td>
	        <td>:</td>
	        <td><?php echo $time?></td>
          </tr>
	      <tr>
	        <td>Number of persons </td>
	        <td>:</td>
	        <td><?php echo $person ?></td>
          </tr>
	      <tr>
	        <td>Service that you like to avail</td>
	        <td>:</td>
	        <td><?php foreach($avail as $value){
			  echo $value ."<br>";}
			?></td>
          </tr>
	      <tr>
	        <td>Coupon code (20% discount with coupon)</td>
	        <td>:</td>
	        <td><?php if ($discount == 'FlyTogether')
				echo "<font color='green'><b> Correct coupon code, you get 20% discount!</b></font>";
			 else
				echo "<font color='red'><b> Sorry the coupon code is invalid!</b></font>";
				?></td>
          </tr>
	      <tr>
	        <td colspan="3">&nbsp;</td>
          </tr>
	      <tr>
	        <td>Price for travel reservation</td>
	        <td>:</td>
	        <td><?php 
				if ($destination == "Langkawi"){
					$price= 50 * $person;
					echo "RM ".$price;
				}
				elseif($destination == "Penang"){
					$price= 75 * $person;
					echo "RM ".$price;
				}
				elseif($destination == "Kuala Lumpur"){
					$price= 90 * $person;
					echo "RM ".$price;
				}
				elseif($destination == "Johor Bahru"){
					$price= 115 * $person;
					echo "RM ".$price;
				}
				elseif($destination == "Kuala Terengganu"){
					$price= 130 * $person;
					echo "RM ".$price;
				}
				elseif($destination == "Kota Kinabalu"){
					$price= 155 * $person;
					echo "RM ".$price;
				}
				elseif($destination == "Kuching"){
					$price= 180 * $person;
					echo "RM ".$price;
				}			
				?></td>
          </tr>
			<tr>
	        <td><strong>TOTAL PRICE</strong></td>
	        <td><strong>:</strong></td>
	        <td><strong>
            <?php if ($discount == 'FlyTogether')
			echo "RM ".$price = $price - ($price * 0.2); 
		  else
			echo "RM ".$price;
	     ?>
	        </strong></td>
          </tr>
      </table>
</body>
</html>
